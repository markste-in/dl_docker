#!/bin/sh
docker build -f dockerfile -t dl_docker .
